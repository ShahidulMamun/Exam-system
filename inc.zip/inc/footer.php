 </section>
<section class="footeroption">
		<h2><?php echo "Online Skill Development Organization"; ?></h2>
		<p style="float: right;color: #ffff">Devoloped By <strong style="font-size:14px">Shahidul Islam Mamun</dtrong></p>

	</section>
</div>
</body>
</html>