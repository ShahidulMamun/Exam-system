<?php

    $filepath = realpath(dirname(__FILE__));
      include_once ($filepath.'/../lib/Session.php');
	    include_once ($filepath.'/../lib/Database.php');
      include_once ($filepath.'/../helpers/Format.php');



class User{
	public $db;
	private $fm;

	public function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
       

	}
     public function userRegistration($name,$username,$password,$email){

           $name      = $this->fm->validation($name);
           $username  = $this->fm->validation($username);
           $password  = $this->fm->validation($password);
           $email     = $this->fm->validation($email);
           $name      = mysqli_real_escape_string($this->db->link,$name);
           $username  = mysqli_real_escape_string($this->db->link,$username);
           $email  = mysqli_real_escape_string($this->db->link,$email);

           if($name=="" || $username=="" || $password=="" || $email==""){
              echo "<span class='error'>Field must not empty</span>";
              exit();
           }else if(filter_var($email, FILTER_VALIDATE_EMAIL)==false){
              echo "<span class='error'>Invalid email address</span>";
              exit();
           }else{
               $checkquery ="SELECT * FROM tbl_user WHERE email= '$email'";
               $checkresult =$this->db->select($checkquery);
               if ($checkresult!=false) {
                 echo "<span class='error'>Email address already exist, please try another email</span>";
              exit();
               }else{
                     $password  = mysqli_real_escape_string($this->db->link,md5($password));
                     $query ="INSERT INTO tbl_user(name, username, password, email)VALUES('$name','$username','$password','$email')";
                     $inserted_row =$this->db->insert($query);
                     if ($inserted_row) {
                       echo "<span class='success'>Registration successfully</span>";
                     exit();
                     }else{
                       echo "<span class='error'>Error......</span>";
                       exit();

                     }

                    
               }
           }
       
      }

      public function userLogin($email,$password){

            $email     = $this->fm->validation($email);
            $password  = $this->fm->validation($password);

            $email     = mysqli_real_escape_string($this->db->link,$email);
            $password  = mysqli_real_escape_string($this->db->link,$password);

             if( $email=="" || $password==""){
              echo "empty";
              exit();
           }else{

                $query  = "SELECT * FROM tbl_user WHERE email='$email' AND password='$password'";
                $result = $this->db->select($query);
                if ($result!= false) {

                  $value = $result->fetch_assoc();
                  if ($value['status']=='1') {
                     echo "disable";
                    exit();
                  }else{
                      Session::init();
                      Session::set("login",true);
                      Session::set("userid",$value['userid']);
                      Session::set("username",$value['username']);
                      Session::set("name",$value['name']);
                     
                  }
                }else{
                  echo "error";
                  exit();
                }
           }
           


      }

      public function updateUserData($userid,$data){

         $name      = $this->fm->validation($data['name']);
         $username  = $this->fm->validation($data['username']);
         $email     = $this->fm->validation($data['email']);
         $name      = mysqli_real_escape_string($this->db->link,$name);
         $username  = mysqli_real_escape_string($this->db->link,$username);
         $email     = mysqli_real_escape_string($this->db->link,$email);

           if($name=="" || $username=="" || $email==""){
              echo "<span class='error'>Field must not empty</span>";
              exit();
           }else if(filter_var($email, FILTER_VALIDATE_EMAIL)==false){
              echo "<span class='error'>Invalid email address</span>";
              exit();
           }/*else{
               $checkquery ="SELECT * FROM tbl_user WHERE email= '$email' AND ";
               $checkresult =$this->db->select($checkquery);
               if ($checkresult!=false) {
                 echo "<span class='error'>Email address already used by other, please try another email</span>";
              exit();
               }*/else{
                   
            
                      $query = "UPDATE tbl_user
                      SET
                      name ='$name',
                      username ='$username',
                      email ='$email'
                      WHERE userid ='$userid' ";
                      $updated_row = $this->db->update($query);
                      if($updated_row){
                         $msg ="<span class='success'>Your information updated successfully!</span>";
                         return $msg;

                     }
                     else{
                         $msg ="<span class='success'>Data Is not updated!</span>";
                         return $msg;
                    }

                    
               }
           }
       
  
  
      public function getUserData($userid){
        $query  = "SELECT * FROM tbl_user WHERE userid='$userid'";
        $result = $this->db->select($query);
        return $result;
      }
      public function getAlluser(){

        $query  = "SELECT * FROM tbl_user ORDER BY userid DESC";
        $result = $this->db->select($query);
        return $result;
      }

      public function DisableUser($userid){

        $query = "UPDATE tbl_user
        SET
        status ='1'
        WHERE userid ='$userid' ";
        $updated_row = $this->db->update($query);
        if($updated_row){

           $msg ="<span class='success'>User disabled </span>";
           return $msg;
           
        }else{

           $msg ="<span class='error'>User Not disabled </span>";
           return $msg;
        }
       

      }
      public function EnableUser($userid){

         $query = "UPDATE tbl_user 
         SET 
         status = 0
         WHERE userid ='$userid'";
         $updated_row = $this->db->update($query);

          if($updated_row){

           $msg ="<span class='success'>User Enabled </span>";
           return $msg;
           
        }else{

           $msg ="<span class='error'>User Not Enabled </span>";
           return $msg;
        }
       


      }

      public function DeleteUser($userid){

        $query = "DELETE FROM tbl_user WHERE userid =$userid";
        $deletedata = $this->db->delete($query);

        if($deletedata){

           $msg ="<span class='success'>User Delete successfully </span>";
           return $msg;
           
        }else{

           $msg ="<span class='error'>User Not Deleted </span>";
           return $msg;
        }
      }

}



?>