<?php

    $filepath = realpath(dirname(__FILE__));
      include_once ($filepath.'/../lib/Session.php');
      include_once ($filepath.'/../lib/Database.php');
      include_once ($filepath.'/../helpers/Format.php');



class Process{
  private $db;
  private $fm;

  public function __construct(){
    $this->db = new Database();
    $this->fm = new Format();
       

  }

  public function processData($data){

       $selectedAns      = $this->fm->validation($data['ans']);
       $quesno      = $this->fm->validation($data['quesno']);
       $selectedAns  = mysqli_real_escape_string($this->db->link,$selectedAns);
       $quesno  = mysqli_real_escape_string($this->db->link,$quesno);
       $next = $quesno+1;

       if (!isset($_SESSION['score'])) {
       	$_SESSION['score']='0';
       }

       $total = $this->getTotal();
       $right = $this->rightAns($quesno);
       
       if ($right==$selectedAns) {
          
           $score=$_SESSION['score']++;
       }

       if ($quesno==$total) {
        header("location:final.php?q=".$next);
        exit();
       }else{
        header("Location:test.php?q=".$next);
       }
	  }
	  private function getTotal(){
	    $query     =  "SELECT * FROM tbl_ques";
	    $getresult = $this->db->select($query);
	    $total     = $getresult->num_rows;
	    return $total;

	  }

	  private function rightAns($quesno){
	  	$query  = "SELECT * FROM tbl_ans WHERE quesno='$quesno' AND rightans='1'";
	    $quisno = $this->db->select($query)->fetch_assoc();
	    $result = $quisno['id'];
      return $result;
	  }

 
}



?>