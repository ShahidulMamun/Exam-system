<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
	 include_once ($filepath.'/../classes/Exam.php');

    $exm = new Exam();
?>
<style>
	
.adminpanel{width:500px;color: #999;margin: 30px;padding:50; margin:  0 auto;}
</style>
<?php    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
       
      $Addques = $exm->AddQuestion($_POST);

    }

    $total = $exm->getTotalRows();
    $next = $total+1;


?>
<div class="main">
<h1>Admin Panel -Add question</h1>
<?php
   if(isset($Addques)){

   	echo $Addques;
   }

?>
   <div class="adminpanel">
   	  <form action="" method="POST">
   	      <table>
           <tr><td>Question No</td><td>:</td><td><input type="number" name="quesno"value="<?php if(isset($next)){
           	    echo $next;}
           	?>"</td></tr>
           <tr><td>Question</td><td>:</td><td><input type="text" name="ques" placeholder="Enter question...." required></td></tr>
           <tr><td>Choice one</td><td>:</td><td><input type="text" name="ans1"  required ></td></tr>
           <tr><td>Choice two</td><td>:</td><td><input type="text" name="ans2"  required ></td></tr>
           <tr><td>Choice three</td><td>:</td><td><input type="text" name="ans3" required ></td></tr>
           <tr><td>Choice four</td><td>:</td><td><input type="text" name="ans4" required ></td></tr>
            <tr><td>Correct</td><td>:</td><td><input type="number" name="rightans" required ></td></tr>

            <tr><td></td><td></td><td><input type="submit" value="Add Question" required ></td></tr>
           </table>
   	  </form>

   </div>


	
</div>
<?php include 'inc/footer.php'; ?>