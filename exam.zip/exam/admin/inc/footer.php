 </section>
<section class="footeroption">
		<h2><?php echo "Online Skill Development Organization"; ?></h2>
</section>
</div>
</body>
</html>