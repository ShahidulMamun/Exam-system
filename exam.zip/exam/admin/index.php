<?php 
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
?>
<style>
	
.adminpanel{width: 500px;color: #999;margin: 30px;padding:50; margin:  0 auto}
</style>

<div class="main">
<h1>Admin Panel</h1>
   <div class="adminpanel">
   	  <h2>Welcome to Admin Panel</h2>
   	  <p>You can manage user and online exam system from here</p>

   </div>


	
</div>
<?php include 'inc/footer.php'; ?>