<?php

    $filepath = realpath(dirname(__FILE__));
      include_once ($filepath.'/../lib/Database.php');
      include_once ($filepath.'/../helpers/Format.php');



class Exam{
  public $db;
  private $fm;

  public function __construct(){
    $this->db = new Database();
    $this->fm = new Format();
       

  }

  public function AddQuestion($data){
     $quesno  = mysqli_real_escape_string($this->db->link,$data['quesno']);
     $ques    = mysqli_real_escape_string($this->db->link,$data['ques']);

     $ans     = array();
     $ans[1]  = $data['ans1'];
     $ans[2]  = $data['ans2'];
     $ans[3]  = $data['ans3'];
     $ans[4]  = $data['ans4'];
     $rightans= $data['rightans'];
     $query ="INSERT INTO tbl_ques(quesno,ques) VALUES('$quesno','$ques')";
     $insert_row = $this->db->insert($query);
     if($insert_row){
      foreach ($ans as $key => $ansName) {

        if($ansName !=''){
          if($rightans==$key){
            $rquery ="INSERT INTO tbl_ans(quesno,rightans,ans) VALUES('$quesno','1','$ansName')";
           
          }else{
             $rquery ="INSERT INTO tbl_ans(quesno,rightans,ans) VALUES('$quesno','0','$ansName')";
              
          } 
          $insertrow = $this->db->insert($rquery);
           
           if($insertrow){
             continue;
           }else{
            die('Error.......');
           }
        }
      }

      $msg  = "<span class='success'> Question is added successfully..</span>";
      return $msg;
     }
          

  }
  
  public function getQuesbyOrder(){

    $query  = "SELECT * FROM tbl_ques ORDER BY quesno ASC"; 
    $result =  $this->db->select($query);
    return $result;

  }

  public function DelQuestion($quesno){
    
    $tables = array("tbl_ques","tbl_ans");
    foreach ($tables as $table) {
     $delquery = "DELETE FROM $table WHERE quesno='$quesno'";
     $deldata  = $this->db->delete($delquery);
    }
    if($deldata){

      $msg = "<span class='success'>Data deledet successfully</span>";
      return $msg;}
      else {
           $smg = "<span class='error'>Data Not deleted</span>";
           return $msg;
     
    }
   
  }

  public function getTotalRows(){

    $query     =  "SELECT * FROM tbl_ques";
    $getresult = $this->db->select($query);
    $total     = $getresult->num_rows;
    return $total;
  }
   public function getQuestion(){
    $query  = "SELECT * FROM tbl_ques";
    $quisno = $this->db->select($query);
    $result = $quisno->fetch_assoc();
    return $result;
  }
  

  public function getQuesByquesno($quesno){
    $query     =  "SELECT * FROM tbl_ques WHERE quesno ='$quesno'";
    $getresult = $this->db->select($query);
    $result = $getresult->fetch_assoc();
    return $result;
  }

  public function getAns($quesno){
    $query     =  "SELECT * FROM tbl_ans WHERE quesno ='$quesno'";
    $getresult = $this->db->select($query);
    return $getresult;
  }


  public function getallAns(){
    $query     =  "SELECT * FROM tbl_ans";
    $getresult = $this->db->select($query);
    return $getresult;
  }
     
}



?>