<?php

    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/Session.php');
	include_once ($filepath.'/../lib/Database.php');
  include_once ($filepath.'/../helpers/Format.php');



class Admin{
	public $db;
	private $fm;

	public function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
       

	}
     public function getAdmindata($data){

           $adminuser  = $this->fm->validation($data['adminuser']);
           $adminpass  = $this->fm->validation($data['adminpass']);
           /*$adminuser  = mysqli_real_escape_string($this->db->link,[$username]);
           $adminpass  = mysqli_real_escape_string($this->db->link,md5($adminpass));*/
          
            $query = "SELECT * FROM tbl_admin WHERE adminuser = '$adminuser' AND adminpass = '$adminpass'";
            $result = $this->db->select($query);
            if($result != false){
            	$value = $result->fetch_assoc();
            	Session::init();
            	Session::set("adminlogin",true);
            	Session::set("adminuser",$value['adminuser']);
            	Session::set("adminid",$value['adminid']);
            	header("Location:index.php");
            } else{

            	$msg = "<span class='error'> Username or Password is wrong!</span>";
            	return $msg;
            }
     }
}



?>