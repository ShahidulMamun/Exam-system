<?php include 'inc/header.php'; ?>
<div class="main">
<h1>Online Exam System</h1>
	<div class="Slider" style="margin-right:30px;">
		
    

	</div>
	


	
</div>
<?php include 'inc/footer.php'; ?>